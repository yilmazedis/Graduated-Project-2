/* ####################################################################### */
/* ***************              LİBRARY'S            ********************* */
/* ####################################################################### */
#include <signal.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <semaphore.h>
#include <pthread.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <errno.h>


#define FILE_NAME_SIZE 50
#define MAX_FILE_SIZE 10485760

int id;
int fd;

/* ####################################################################### */
/***********                GLOBAL  PARAMETERS                   ***********/
/* ####################################################################### */
int welcomeSocket, newSocket;
struct sockaddr_in serverAddr;
struct sockaddr_in serverStorage;
socklen_t addr_size;
int flag = 0;




typedef struct{
    char filename[FILE_NAME_SIZE];
    char data[MAX_FILE_SIZE];
    long len;
}xValues;

xValues getElement;

char* readFileBytes(const char *name, long *lenf);
void writeFileBytes(const char *name, char* data, long lenf);

/* ####################################################################### */
/* ***************           MAİN FUNCTİON         *********************** */
/* ####################################################################### */
int main(int argc,char **argv){

   int socketget;

   welcomeSocket = socket(PF_INET, SOCK_STREAM, 0);


    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(atoi(argv[1]));
    serverAddr.sin_addr.s_addr =inet_addr("127.0.0.1");
    memset(serverAddr.sin_zero, '\0', sizeof serverAddr.sin_zero);


    /*---- Bind the address struct to the socket ----*/
    bind(welcomeSocket, (struct sockaddr *) &serverAddr, sizeof(serverAddr));

    /*---- Listen on the socket, with 5 max connection requests queued ----*/
    if(listen(welcomeSocket,100)!=0){
    	perror("listen ");
    }


    /*---- Accept call creates a new socket for the incoming connection ----*/
    addr_size = sizeof(serverStorage);
    socketget = accept(welcomeSocket, (struct sockaddr *) &serverStorage, &addr_size);

    read(socketget,&getElement,sizeof(getElement));


    printf("%s\n", getElement.filename);

    writeFileBytes("./serverDir/osmanKro.pdf", getElement.data, getElement.len);

    printf("End Of Server\n");

    close(welcomeSocket);
    
    return 0;
}

char* readFileBytes(const char *name, long *lenf)  
{  
    FILE *fl = fopen(name, "r"); 
    fseek(fl, 0, SEEK_END);  
    long len = ftell(fl);  
    char *ret = malloc(len);  
    fseek(fl, 0, SEEK_SET);  
    fread(ret, 1, len, fl);  
    fclose(fl);

    *lenf = len;
    return ret;  
}

void writeFileBytes(const char *name, char* data, long lenf)  
{  
    FILE *fl = fopen(name, "wb");  
    
    fwrite(data, lenf, 1, fl);
    fclose(fl);


    return;  
} 