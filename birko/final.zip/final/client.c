/* ####################################################################### */
/* ***************              LİBRARY'S            ********************* */
/* ####################################################################### */
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <semaphore.h>
#include <pthread.h>

#define FILE_NAME_SIZE 50
#define MAX_FILE_SIZE 10485760

/* ####################################################################### */
/***********                GLOBAL  PARAMETERS                   ***********/
/* ####################################################################### */

typedef struct{
    char filename[FILE_NAME_SIZE];
    char data[MAX_FILE_SIZE];
    long len;
}xValues;

xValues getElement;

char buffer[1024];
struct sockaddr_in serverAddr;
socklen_t addr_size;

char* readFileBytes(const char *name, long *lenf);
void writeFileBytes(const char *name, char* data, long lenf);
void removeFile(char * filename);

/* ####################################################################### */
/* ***************           MAİN FUNCTİON         *********************** */
/* ####################################################################### */
int main(int argc,char **argv){

	int clientSocket;
    long i,j;
    long len;
    char* data;

    // removeFile("./clientDir/HW6.pdf");

    /*
    data = readFileBytes("./clientDir/HW6.pdf", &len);
    printf("%ld\n", len);

    writeFileBytes("./serverDir/test.pdf", data, len);
	*/
	
	
	if (argc != 4)
	{
		printf("usage : ./client  <dirname> <port> <ip : 127.0.0.1> \n");
		exit(1);
	}

    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(atoi(argv[2]));
    serverAddr.sin_addr.s_addr = inet_addr(argv[3]);
    memset(serverAddr.sin_zero, '\0', sizeof serverAddr.sin_zero); 

    clientSocket = socket(PF_INET, SOCK_STREAM, 0);
    addr_size = sizeof(serverAddr);
    
    if (connect(clientSocket, (struct sockaddr *) &serverAddr, addr_size) == -1){
		perror("Connection Error");
    }else{
    	printf("Connection is successed\n");
    }

    ////////////////////////////////////////
    // Fill Struct Part

    data = readFileBytes("./clientDir/HW6.pdf", &len);


    printf("%ld\n", len);

    for (i = 0; i < len; ++i)
    {
    	getElement.data[i] = data[i];
    }

    
    getElement.len = len;


    sprintf(getElement.filename,"%s", "HW6.pdf");
    ////////////////////////////////////////
    

    write(clientSocket,&getElement,sizeof(xValues));

    //read(clientSocket,&getElement,sizeof(xValues));

    printf("End Of Client\n");

    close(clientSocket);

    return 0;
}

void removeFile(char * filename) {

	int status;

	status = remove(filename);

	if (status == 0)
		printf("%s file deleted successfully.\n",filename);
	else
	{
		printf("Unable to delete the file\n");
		perror("Following error occurred");
	}
}

char* readFileBytes(const char *name, long *lenf)  
{  
    FILE *fl = fopen(name, "r");  
    fseek(fl, 0, SEEK_END);  
    long len = ftell(fl);  
    char *ret = malloc(len);  
    fseek(fl, 0, SEEK_SET);  
    fread(ret, 1, len, fl);  
    fclose(fl);

    *lenf = len;
    return ret;  
}

void writeFileBytes(const char *name, char* data, long lenf)  
{  
    FILE *fl = fopen(name, "wb");  
    

    fwrite(data, lenf, 1, fl);

    fclose(fl);


    return;  
} 